# Step 3 walkthrough: API and persistence

Step 3 adds three files in `backend/app/`, which turn the state machine into a running web service:

| File | Role |
|---|---|
| `config_store.py` | Saves and loads the cell configuration with `vention-storage` (SQLite). |
| `api.py` | The RPC actions and the telemetry stream, with `vention-communication`. |
| `main.py` | Creates the app, wires everything together at startup, and is what `uvicorn` runs. |

Plus `backend/.gitignore` (ignores the `data/` folder holding the database), the generated `backend/proto/app.proto`, and tests (`tests/test_api.py`, with the fake drivers moved to `tests/fakes.py`).

How a request flows:

```
frontend ──HTTP POST /rpc/.../start_sequence──▶ api.start_sequence()
                                                   └─▶ runtime.machine.request_start()   (Step 2)
frontend ◀──stream /rpc/.../telemetry── telemetry_loop() every 50 ms ◀── machine.status()
api.set_config() ─▶ machine.update_config() (validates) ─▶ store.save() ─▶ SQLite
```

---

## Part 1 — `config_store.py`

### 1.1 Module docstring: why there's no `bootstrap()`

`vention-storage`'s `bootstrap()` (in `storage/bootstrap.py`) is the library's Quickstart. Besides connecting to the database, it **always** mounts HTTP endpoints for every registered model (`build_crud_router`): `GET/POST/PUT/DELETE /cell_config/...`. It also adds a `/db` router with backup and **restore**, which uploads a whole database file. Those endpoints write to the database directly, so they would:

- skip `validate_config` (a cube at (600, 0) would be saved);
- ignore the "only while `ready`" rule;
- not update the machine, which keeps its config in memory (a "ghost" change that only applies after a restart).

`enable_db_router=False` removes `/db`, but the CRUD endpoints can't be turned off. So we use the lower-level functions that `bootstrap()` itself calls: `set_database_url`, `get_engine`, `ModelAccessor`. We still get the library's sessions and its **audit log** of every change, and `set_config` stays the only way to change the configuration.

### 1.2 `ConfigRecord`: the database table

```python
class ConfigRecord(SQLModel, table=True):
    __tablename__ = "cell_config"
    id: Optional[int] = Field(default=None, primary_key=True)
    cube_x: float
    cube_y: float
    ...
    speed: int
```

- `vention-storage` works with **SQLModel** classes (a mix of a Pydantic model and an SQLAlchemy table). `table=True` makes it a real table.
- It's a **flattened** `CellConfig`. SQL columns hold single values, not tuples, so `cube=(x, y)` becomes `cube_x` and `cube_y`.
- `__tablename__` fixes the table name instead of letting SQLModel derive it from the class name.
- There's only ever **one row**, with `id = CONFIG_ROW_ID = 1`.

### 1.3 `init_database(url)`

```python
def init_database(url: str) -> None:
    try:
        set_database_url(url)
    except RuntimeError:
        pass
    SQLModel.metadata.create_all(get_engine())
```

- `set_database_url` tells the library which database file to use. `create_all` creates any missing tables: ours and the library's `AuditLog`.
- **The library's engine is a process-wide singleton** (`storage/database.py`): the URL can only be set before the engine is first used, and setting it again raises `RuntimeError`. A real server starts once, so that never happens. Tests start the app several times in one process, so a second call just keeps the existing engine and ensures the tables exist.

### 1.4 `ConfigStore`

```python
class ConfigStore:
    def __init__(self):
        self._accessor = ModelAccessor(ConfigRecord, "cell_config")

    def load(self) -> Optional[CellConfig]:
        record = self._accessor.get(CONFIG_ROW_ID)
        return _to_config(record) if record else None

    def save(self, config, actor="operator"):
        self._accessor.save(_to_record(config), actor=actor)
```

- `ModelAccessor` is the library's read/write helper for one model. Each write runs in a transaction and adds an audit entry (who, when, before and after).
- `load()` returns `None` when nothing has been saved yet. Deciding what to do then (use the defaults) is `main.py`'s job, not the store's.
- `save()` uses the accessor's `save`, which **inserts** the row the first time and **updates** it afterwards.
- `actor` is recorded in the audit log: `"operator"` for changes coming from the API, `"system"` for defaults written at startup, `"test"` in tests.
- `_to_record` / `_to_config` convert between the flat table row and the `CellConfig` dataclass the rest of the code uses. The database shape stays inside this file.

---

## Part 2 — `api.py`

### 2.1 Module docstring: how the library registers endpoints

- `@action()` and `@stream()` **register into module-level lists when the file is imported**. `VentionApp.finalize()` (in `main.py`) then reads those lists and creates the routes.
- Routes are `POST /rpc/vention.app.v1.GantryAppService/<function_name>`. The service name comes from the app name `"GantryApp"`.
- **Handlers never raise for expected refusals.** The library turns any exception into an HTTP **200** response with a body like `{"error": {"code": "...", "message": "..."}}`. A generated client would then see a "successful" response with an unexpected shape. So every command returns a `CommandResult` with `ok` and `error`.
- **Field naming on the wire** (found while testing):
  - **Requests** accept camelCase *or* snake_case (`pickZ` or `pick_z`). The library adds camelCase aliases for input. Generated Connect clients send camelCase.
  - **Responses** use snake_case (`gripper_closed`). That's the proto field name, which protobuf JSON parsers also accept, so the frontend client reads it fine.

### 2.2 `Runtime`: how handlers reach the machine

```python
class Runtime:
    machine: GantryMachine
    store: ConfigStore

runtime = Runtime()
```

Because the endpoints are registered once at import, they must be plain module-level functions. They can't be methods of an object built later with a particular machine. Each handler looks the machine up **when it's called** through `runtime`, which `main.py` fills in at startup and tests replace before each test. This keeps all the "global" state in one obvious place.

The cleaner alternative would be FastAPI's dependency injection (`Depends`), but the `@action` decorator builds the routes itself and doesn't support it.

### 2.3 Messages (Pydantic models)

```python
class Point2(BaseModel): x: float; y: float
class Point3(BaseModel): x: float; y: float; z: float
class Config(BaseModel): cube: Point2; destination: Point2; home: Point3; safe_z; pick_z; speed: int
class CommandResult(BaseModel): ok: bool; error: str = ""
class Telemetry(BaseModel): state; position; gripper_closed; moving; cube_position; destination_position; error
```

- These define the JSON shapes **and** the generated `proto/app.proto`. The class names become proto message names.
- **Why `Point2`/`Point3` instead of tuples?** The proto generator only understands numbers, strings, booleans, lists and nested models. A tuple would silently become `string`. Nested models give the frontend proper typed `{x, y, z}` objects.
- **Why `error: str = ""` instead of `Optional[str]`?** Proto3 has no "null" for strings, so the generator maps `Optional[str]` to plain `string` anyway. An empty string as "no error" is the honest proto equivalent.
- `speed: int` matches `CellConfig.speed` and the simulator. A request with `speed: 50.5` is rejected by Pydantic validation.

### 2.4 Actions

Each action is a small adapter: convert the request, call the machine, convert the result.

| Action | Input → Output | Calls |
|---|---|---|
| `get_config` | — → `Config` | `machine.config` |
| `set_config` | `Config` → `CommandResult` | `machine.update_config()` then `store.save()` |
| `get_robot_position` | — → `Point3` | `machine.driver.position` |
| `move_robot` | `Point3` → `CommandResult` | `machine.request_jog()` |
| `home_robot` | — → `CommandResult` | `machine.request_home()` |
| `start_sequence` | — → `CommandResult` | `machine.request_start()` |
| `stop` | — → `CommandResult` | `machine.request_stop()` |
| `reset_fault` | — → `CommandResult` | `machine.request_reset()` |
| `get_status` | — → `Telemetry` | `machine.status()` |

- An action with no parameter gets `google.protobuf.Empty` as its input. The library infers input and output types from the function's annotations.
- **`set_config` order matters:** the machine validates and applies first, and only then is the config saved. A rejected config is never written to the database. If saving fails (e.g. the disk is full), the machine already uses the new config, so the error says "applied but not saved" instead of pretending nothing happened.
- `result(error)` turns the machine's `None`-or-message convention into `CommandResult(ok=..., error=...)`.

### 2.5 Telemetry

```python
@stream(name="telemetry", payload=Telemetry, replay=True, queue_maxsize=1, policy="latest")
async def publish_telemetry() -> Telemetry:
    return status_to_telemetry(runtime.machine.status())

async def telemetry_loop():
    while True:
        try:
            await publish_telemetry()
        except Exception:
            logger.exception("Telemetry publish failed")
        await asyncio.sleep(TELEMETRY_PERIOD_S)
```

- `@stream` turns the function into a **publisher**: calling it computes the value and sends it to every subscriber.
- Its settings fit live status:
  - `replay=True`: a new subscriber immediately gets the last value, so a freshly opened dashboard isn't blank.
  - `queue_maxsize=1` with `policy="latest"`: each subscriber only keeps the newest message. A slow browser tab skips stale positions instead of falling behind, and the publisher never waits.
- `telemetry_loop` publishes every 50 ms (target 20 per second; measured about 17 per second on Windows, where sleep timers are coarse). If one tick fails it logs and keeps going: the stream must not die because of one bad tick.
- On the wire, each message is a **Connect frame**: 1 flag byte, 4 bytes of length, then the JSON. The generated frontend client decodes this.

### 2.6 Conversions

`point3`, `config_to_message`, `message_to_config` and `status_to_telemetry` convert between the API's Pydantic messages and the internal `CellConfig` / `MachineStatus` dataclasses. The machine never deals with HTTP shapes, and the API can change shape without touching the machine. `status.last_error or ""` maps `None` to the empty string (section 2.3).

---

## Part 3 — `main.py`

### 3.1 Paths and settings

```python
BACKEND_DIR = Path(__file__).resolve().parent.parent
DEFAULT_DB_URL = f"sqlite:///{(BACKEND_DIR / 'data' / 'gantry.db').as_posix()}"
PROTO_PATH = BACKEND_DIR / "proto" / "app.proto"
FRONTEND_ORIGINS = ["http://localhost:5173", "http://127.0.0.1:5173"]
```

- Paths are built from this file's location, not the current directory, so the database and proto always land in `backend/` wherever uvicorn is started from.
- `.as_posix()` gives forward slashes, which SQLite URLs need even on Windows.
- `FRONTEND_ORIGINS` are the Vite dev server's addresses (Step 4), allowed through CORS.

### 3.2 `load_startup_config`

```python
def load_startup_config(store, machine_limits) -> CellConfig:
    saved = store.load()
    if saved is not None:
        error = validate_config(saved, machine_limits)
        if error is None:
            return saved
        logger.warning("Ignoring invalid saved configuration: %s", error)
    config = CellConfig()
    store.save(config, actor="system")
    return config
```

- It uses the saved config only if it's **still valid**. A saved config could become invalid if, say, the table layout constants change in a later version. Starting the machine with it would make every Start fail.
- If there's no valid saved config, it uses the defaults and **saves them**, so the database always holds what the machine is actually using.

### 3.3 `lifespan`: startup and shutdown

```python
@asynccontextmanager
async def lifespan(_):
    db_url = os.getenv("GANTRY_DB_URL", DEFAULT_DB_URL)
    ...
    init_database(db_url)
    store = ConfigStore()
    machine = GantryMachine()
    machine.update_config(load_startup_config(store, machine.driver.limits))
    api.runtime.store = store
    api.runtime.machine = machine
    telemetry = asyncio.create_task(api.telemetry_loop())
    try:
        yield
    finally:
        telemetry.cancel()
        ...
        await machine.cancel_tasks()
```

- FastAPI runs everything **before** `yield` at startup and everything **after** it at shutdown.
- **Why not do this at import?** Importing `app.main` (as tests do) shouldn't open a database or create a robot. The `GANTRY_DB_URL` environment variable lets tests point at a throwaway database instead of `data/gantry.db`.
- The machine gets the config through `update_config`, the same validated path the API uses, which also passes the home position to the driver.
- The telemetry loop runs as a background task for the server's whole life.
- At shutdown the telemetry task is cancelled and awaited (`suppress(CancelledError)` because that's the expected result), and any running motion task is cancelled.

### 3.4 Creating the app

```python
app = VentionApp(name="GantryApp", emit_proto=True, proto_path=str(PROTO_PATH), lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=FRONTEND_ORIGINS, allow_methods=["*"], allow_headers=["*"])
app.finalize()
```

- `VentionApp` is a FastAPI subclass, so normal FastAPI options like `lifespan` and middleware work.
- `from app import api` at the top of the file is what **registers** the actions: importing `api.py` runs the decorators. `finalize()` must come after that import.
- `emit_proto=True` writes `proto/app.proto` during `finalize()`. Step 4 generates the TypeScript client from it.
- **CORS:** the frontend runs on port 5173 and the backend on 8000. Browsers treat different ports as different origins and block the calls unless the backend allows them. `allow_headers=["*"]` covers the Connect protocol's own headers (`connect-protocol-version`, etc.).

---

## Part 4 — Tests

### 4.1 `tests/fakes.py`

`FastDriver` (teleports, keeps the simulator's validation, records targets) and `StuckDriver` (never finishes a move) moved here from `test_machine.py`, so the machine and API tests share them.

### 4.2 `tests/test_api.py`

**Fixtures:**
- `database` (session-wide): points `GANTRY_DB_URL` at a temporary file. The storage engine is a singleton, so the whole session shares one database.
- `app_client` (session-wide): **one** `TestClient` for all tests. The communication library's stream queues bind to the first event loop that uses them, and each `with TestClient(app)` starts a new loop, so a second client breaks streaming. A real server only has one loop, so this only matters for tests.
- `client` (per test): saves the default config and installs a fresh `GantryMachine` with the `FastDriver` into `runtime`. Each test starts clean even though the app is shared.

**What's covered (18 tests):**
- Status starts in `ready` with snake_case fields, and the config defaults are returned.
- `set_config` applies and saves; it's checked by reading the database.
- An off-table cube is rejected and **not** saved.
- camelCase requests are accepted, as the generated client sends them.
- A malformed request gets the library's error envelope.
- A full `start_sequence` ends with the cube at the destination.
- Start is refused while busy.
- Jog and get position; a jog outside the limits is refused without a fault; homing.
- Stop goes to fault with "Stopped by operator", and reset goes back to `ready` with the error cleared. Reset is refused when not faulted.
- The config survives a restart (a fresh store plus a new machine loading from the database).
- An invalid saved config falls back to the defaults.
- The telemetry stream publishes a status message.
- The proto lists every RPC.

The whole backend suite is 65 tests and runs in about 3 seconds.

---

## Verification on the real server

`uvicorn app.main:app --port 8000`, driven over real HTTP with the real simulator:

- The CORS preflight from `http://localhost:5173` was allowed.
- `set_config` with camelCase fields returned `ok: true`.
- The telemetry stream returned `application/connect+json` frames.
- `start_sequence` returned `ok: true`; a second `start_sequence` was refused: *"Cannot start sequence while the machine is in state 'PickPlace_moveToCube'"*.
- Every state was received through the stream: `moveToCube` (8.1 s) → `lowerToCube` → `grip` → `liftCube` → `moveToDest` (27.5 s) → `lowerToDest` → `release` → `liftClear` → `ready` at **32.8 s**. That's 554 telemetry frames, about 17 per second.
- The final cube position equals the destination (603.553, −267.157, −250) on Table B.
- **Restart:** the server was stopped and started again, and `get_config` returned the saved config (cube (100, 400), destination (50, 450), pick height −250).

---

## Library quirks found in this step

| Quirk | How we handle it |
|---|---|
| `bootstrap()` always mounts unvalidated CRUD endpoints | Don't use it; use `set_database_url` / `get_engine` / `ModelAccessor` directly. |
| The storage engine is a process-wide singleton (URL set once) | `init_database` tolerates a second call; tests share one database. |
| Exceptions in actions become HTTP 200 with an `error` body | Actions return `CommandResult` instead of raising. |
| Responses are snake_case although requests accept camelCase | Documented; protobuf JSON parsers accept both, so the generated client works. |
| Tuples map to `string` in the generated proto | Use `Point2` / `Point3` models. |
| `Optional[str]` maps to plain proto `string` | Use `""` for "no error". |
| Stream queues bind to the first event loop | One `TestClient` per test session. |
