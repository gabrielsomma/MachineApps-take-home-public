# `backend/app/machine.py` walkthrough

The file has three layers:

1. **Definitions:** which states exist and how they connect. This is data, with no behaviour.
2. **Commands:** what the API calls, such as "home" or "start".
3. **State hooks:** what happens when the machine *enters* each state.

---

## 1. Module docstring

It says two things worth knowing before reading the code:

- **State names are `<Group>_<member>`,** e.g. `PickPlace_moveToCube`. The library joins the group and member with `_`, so a member called `move_to_cube` crashes it (found during setup). That's why the members are camelCase.
- **How a step works:** entering a motion state starts a background task. The task moves the robot, then fires the next trigger. Errors and timeouts go to `fault`.

---

## 2. Imports

```python
from transitions.core import MachineError
from state_machine.core import BaseStates, BaseTriggers, StateMachine
from state_machine.decorators import guard, on_enter_state, on_exit_state
from state_machine.defs import State, StateGroup, Trigger
```

- `vention-state-machine` is built on the open-source **`transitions`** library. `MachineError` comes from there: it's raised when you fire a trigger that has no transition from the current state.
- `BaseStates` and `BaseTriggers` are the library's built-in names: `ready` and `fault`; `reset` and `to_fault`.
- The decorators attach our methods to states (`on_enter_state`, `on_exit_state`) and to triggers (`guard`).
- `dataclasses.replace` is used to copy a config (section 8).

---

## 3. States

```python
class Homing(StateGroup):
    moving = State()

class Manual(StateGroup):
    moving = State()

class PickPlace(StateGroup):
    moveToCube = State()
    lowerToCube = State()
    ...
    liftClear = State()

class States:
    homing = Homing()
    manual = Manual()
    pick_place = PickPlace()
```

- A **`StateGroup`** is a folder of related states. Each `State()` becomes a leaf state named `Group_member`.
- **`Homing` and `Manual` have a single state** (`moving`) because the library only accepts groups. A bare top-level state isn't possible.
- **`PickPlace`** lists the 8 steps from the README, in order:
  - move above the cube, lower, grip, lift;
  - move above the destination, lower, release, lift clear.
- **`States`** is the container passed to the library. It collects every group instance.
- `ready` and `fault` are added automatically by the library.

---

## 4. Triggers

```python
class Triggers:
    home = Trigger("home")
    jog = Trigger("jog")
    start_sequence = Trigger("start_sequence")
    next = Trigger("next")
    done = Trigger("done")
```

A trigger is a **named event**. Firing it moves the machine along a transition, if one exists from the current state.

- `home`, `jog` and `start_sequence` are fired by user commands.
- `next` is fired internally when a pick-and-place step finishes.
- `done` is fired when an operation's last step finishes and the machine goes back to `ready`.
- `to_fault` and `reset` are built in. Trigger names *can* contain underscores; only state member names can't.

---

## 5. Transitions

```python
READY = BaseStates.READY.value     # "ready"
FAULT = BaseStates.FAULT.value     # "fault"

PICK_PLACE_STEPS = [PickPlace.moveToCube, ..., PickPlace.liftClear]

TRANSITIONS = [
    Triggers.home.transition(READY, Homing.moving),
    Triggers.done.transition(Homing.moving, READY),
    Triggers.jog.transition(READY, Manual.moving),
    Triggers.done.transition(Manual.moving, READY),
    Triggers.start_sequence.transition(READY, PickPlace.moveToCube),
    *[Triggers.next.transition(step, following)
      for step, following in zip(PICK_PLACE_STEPS, PICK_PLACE_STEPS[1:])],
    Triggers.done.transition(PickPlace.liftClear, READY),
]
```

- Each `.transition(source, dest)` reads "this trigger moves the machine from *source* to *dest*".
- **Every operation starts from `ready`.** You can't home in the middle of a sequence, because there's simply no transition for it. The structure itself prevents conflicting commands.
- **The `zip(...)` line** pairs each step with the following one: (moveToCube, lowerToCube), (lowerToCube, grip), …, (release, liftClear). That gives 7 `next` transitions without writing them by hand. The order lives in one list, `PICK_PLACE_STEPS`.
- **Built-in transitions:** the library adds `to_fault` from **any** state (`*`) to `fault`, and `reset` from `fault` to `ready`.

The whole machine:

```
ready ──home──▶ Homing_moving ──done──▶ ready
ready ──jog───▶ Manual_moving ──done──▶ ready
ready ──start_sequence──▶ moveToCube ─next▶ lowerToCube ─next▶ grip ─next▶ liftCube
        ─next▶ moveToDest ─next▶ lowerToDest ─next▶ release ─next▶ liftClear ──done──▶ ready
(any) ──to_fault──▶ fault ──reset──▶ ready
```

---

## 6. `MachineStatus`

```python
@dataclass
class MachineStatus:
    state: str
    position: list[float]
    gripper_closed: bool
    moving: bool
    cube_position: list[float]
    destination_position: list[float]
    last_error: Optional[str]
```

This is a snapshot of everything the dashboard shows, matching the README's telemetry list: position, cube and destination, gripper, moving or idle, and current state, plus the last error for the fault display. The telemetry stream publishes this about 20 times a second.

---

## 7. The class and its constructor

```python
class GantryMachine(StateMachine):
    GRIPPER_DELAY_S = 0.3
    TIMEOUT_FACTOR = 1.5
    TIMEOUT_MARGIN_S = 2.0
```

- These are **tunable constants** stored on the class. Tests override them per instance, e.g. setting the gripper delay to 0 so tests run fast.
- `GRIPPER_DELAY_S`: the simulator's gripper switches instantly, so we wait 0.3 s to make it look realistic.
- The timeout constants are explained in section 11.

```python
def __init__(self, driver=None, config=None):
    self.driver = driver or RobotDriver()
    self.config = config or CellConfig()
    self.last_error = None
    self._jog_target = self.driver.position
    self._holding_cube = False
    self._cube_rest = []
    self._place_cube_at_start()
    self.driver.home_position = self.config.home
    super().__init__(States, transitions=TRANSITIONS, enable_last_state_recovery=False)
```

- **`driver` and `config` can be passed in.** Tests pass a fast fake driver; the real app passes the config loaded from storage.
- **Our attributes are set before `super().__init__`** because the library calls our hooks during setup, and they must already exist.
- `_jog_target`: where a jog should go. It's stored here because a hook can't receive arguments directly (section 10).
- `_holding_cube` and `_cube_rest`: the simulated cube (section 13).
- **`enable_last_state_recovery=False`:** by default the library tries to resume the last state after a restart. Restarting into, say, `lowerToDest` with no idea where the robot really is would be unsafe, so it's off.
- **The machine starts in `ready`.** We never call the library's `start()`; it would need a `start` transition that we don't use.

---

## 8. Commands

These are the methods the API calls. **Every one returns `None` on success, or a human-readable reason it was refused.** The API passes that string straight to the frontend.

```python
def request_home(self):
    return self._fire(Triggers.home)
```

It just fires the trigger. `_fire` turns "not allowed" into a message (section 11).

```python
def request_jog(self, target):
    if len(target) != 3: return "Position must have 3 axes..."
    if any(abs(v) > limit for v, limit in zip(target, self.driver.limits)):
        return "... outside the robot limits ..."
    if self.state != READY: return self._not_ready("move the robot")
    self._jog_target = [float(v) for v in target]
    return self._fire(Triggers.jog)
```

- The target is checked **before** moving. An out-of-range jog is refused politely instead of faulting the machine, because a typo shouldn't need a Reset.
- The `ready` check comes **before** `_jog_target` is overwritten, so a refused jog can't change the target of one already running.

```python
def request_start(self):
    error = validate_config(self.config, self.driver.limits)
    if error: return error
    return self._fire(Triggers.start_sequence)
```

It checks the config first to get a precise message, such as "Cube position (600, 0) is not on Table A". A guard (section 9) checks it again, but a guard can only say yes or no.

```python
def request_stop(self):
    if self.state == FAULT: return None
    self._fault("Stopped by operator")
    return None
```

- This is an operator stop. Going to `fault` cancels all motion immediately.
- It's always allowed and never refused; stopping must always work.
- Stopping while already faulted does nothing.

```python
def request_reset(self):
    if self.state != FAULT: return "Reset is only needed after a fault"
    return self._fire(BaseTriggers.RESET.value)
```

It acknowledges a fault and goes back to `ready`.

```python
def update_config(self, config):
    if self.state != READY: return self._not_ready("change the configuration")
    error = validate_config(config, self.driver.limits)
    if error: return error
    self.config = replace(config)
    self.driver.home_position = config.home
    self._place_cube_at_start()
    return None
```

- **Only allowed in `ready`.** Changing the destination while the robot is carrying the cube would be dangerous.
- `replace(config)` stores a **copy**, so the caller can't change the live config afterwards. That's the same idea as the copies in the driver.
- The new home position is passed to the driver, and the simulated cube moves to the new start position.

`status()` builds the `MachineStatus` snapshot. The destination is reported in robot coordinates at pick height, so the frontend can draw it directly. `cube_position` is explained in section 13.

---

## 9. Guards

```python
@guard(Triggers.start_sequence)
def _config_is_valid(self) -> bool:
    return validate_config(self.config, self.driver.limits) is None

@guard(Triggers.home, Triggers.jog, Triggers.start_sequence)
def _robot_is_idle(self) -> bool:
    return not self.driver.is_moving
```

- A **guard** is a yes-or-no check that the library runs before a transition. If it returns `False`, the transition is blocked and `trigger()` returns `False`.
- **Why guards, when the commands already check?** The commands give friendly messages, while guards make the machine **itself** enforce the rules, however it's triggered: by a test, a future API endpoint, or a direct `trigger()` call. For example, a test that tried to bypass validation with `trigger("start_sequence")` was stopped by the guard.
- `_robot_is_idle` is an extra safety net: never start a new motion while the robot is still physically moving.

---

## 10. State hooks: what each state does

`@on_enter_state(X)` means "run this method when the machine enters state X". The `_` parameter is an event object the library passes in, which we don't use. All the hooks follow one pattern: **start the work in the background with `_run_step`, then return immediately.**

Why return immediately? The library calls hooks **synchronously**, in the middle of a transition. If a hook waited 6 seconds for the robot to move, the whole server would freeze: no API responses, no telemetry. So the hook starts the move and returns, and when the move finishes, `_run_step` fires the next trigger.

```python
@on_enter_state(Homing.moving)
def _enter_homing(self, _):
    self._run_step(lambda: self._travel_to(self.config.home), Triggers.done)
```

- `lambda: ...` passes a *recipe* for the work instead of starting it on the spot. `_run_step` decides when to run it.
- `_travel_to` lifts to travel height first if needed (section 11).
- When it's finished, `done` is fired, which leads back to `ready`.

```python
@on_enter_state(Manual.moving)
def _enter_manual(self, _):
    self._run_step(lambda: self._move(self._jog_target), Triggers.done)
```

A jog goes **straight** to the target, with no automatic lift, because the operator chose that exact point.

```python
@on_enter_state(PickPlace.moveToCube)
def _enter_move_to_cube(self, _):
    self.driver.open_gripper()
    self._place_cube_at_start()
    self._run_step(lambda: self._travel_to(self._above(self._cube_xy())))
```

The first step of a sequence:

- **Opens the gripper**, in case a previous run faulted while holding the cube.
- **Puts the simulated cube back** at its start position (the "each Start assumes the cube was put back" assumption).
- Travels above the cube, lifting first if the robot is low.
- `on_success` defaults to `next`, so it continues to `lowerToCube`.

The remaining steps are the same pattern with different targets:

| Hook | Work | Target |
|---|---|---|
| `lowerToCube` | `_move` | (cube x, cube y, **pick_z**) |
| `grip` | close gripper, mark cube as held, wait 0.3 s | — |
| `liftCube` | `_move` | (cube x, cube y, **safe_z**) |
| `moveToDest` | `_move` | (dest x, dest y, safe_z) |
| `lowerToDest` | `_move` | (dest x, dest y, pick_z) |
| `release` | open gripper, leave cube where it is, wait 0.3 s | — |
| `liftClear` | `_move`, then fire **`done`** | (dest x, dest y, safe_z) |

`grip` and `release` define small `async def` functions instead of lambdas, because they do several things including an `await`.

```python
@on_enter_state(FAULT)
def _enter_fault(self, _):
    self._clear_all_timeouts()
    current = asyncio.current_task() if _loop_running() else None
    for task in list(self._tasks):
        if task is not current:
            task.cancel()
```

**This is the most important hook.** The library's built-in `to_fault` is meant to cancel running tasks, but its cleanup is an `async` function the synchronous transition never awaits. So it silently does nothing (verified in a smoke test during setup). Without this hook, a robot would **keep moving after a fault**. What it does:

- Cancels pending timeouts.
- Cancels every running background task. The driver's `finally` block then stops the robot cleanly.
- **Skips the current task:** the task that *triggered* the fault (a move that just failed) is the one running this code. It's finishing anyway, so there's no point cancelling it.
- `list(self._tasks)` takes a copy because cancelled tasks remove themselves from the set as we loop, and changing a set while looping over it is an error.

```python
@on_exit_state(FAULT)
def _exit_fault(self, _):
    self.last_error = None
```

Leaving `fault` (via reset) clears the error. It stays visible for the whole time the machine is faulted.

---

## 11. Helpers

### `_run_step`: the engine behind every step

```python
def _run_step(self, work, on_success=Triggers.next):
    state = self.state

    async def runner():
        try:
            await work()
        except MotionError as exc:
            self._fault(str(exc)); return
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._fault(f"Unexpected error in {state}: {exc}"); return
        if self.state == state:
            self.trigger(on_success.name)

    self.spawn(runner())
```

- **`state = self.state`** remembers which state started this work.
- **`self.spawn(...)`** is the library's way to start a background task. It also tracks the task in `self._tasks`, which is how `_enter_fault` finds it to cancel.
- **`MotionError`** (an out-of-limits move, from the driver) goes to fault with the simulator's message.
- **`CancelledError` is re-raised on purpose.** It means "you were cancelled", usually by a fault. Catching it would make the cancel fail silently. In Python 3.10 `CancelledError` doesn't inherit from `Exception`, but stating it explicitly makes the intent clear.
- **Any other exception** also faults. A bug must stop the machine, never leave it stuck in a motion state.
- **`if self.state == state`** only advances if we're *still* in the state that started the work. If a stop or timeout moved the machine to `fault` while the work was finishing, firing `next` from `fault` would be wrong.

### `_move`: a single move with a timeout

```python
async def _move(self, target):
    self.set_timeout(self.state, self._timeout_for(target), self._on_timeout)
    await self.driver.move(target, self.config.speed)
```

`set_timeout` is the library's timeout. If the machine is still in this state after N seconds, it calls `_on_timeout` and fires the trigger that returns. The library clears the timeout automatically when the state is left. When a state makes two moves (lift, then travel), the second call replaces the first timeout.

### `_travel_to`: lift first

```python
async def _travel_to(self, target):
    x, y, z = self.driver.position
    if z < self.config.safe_z:
        await self._move([x, y, self.config.safe_z])
    await self._move(target)
```

If the robot is low, for example after a fault mid-lowering, a straight diagonal move would drag the gripper across a table. So it rises straight up first. Homing and `moveToCube` use this; the other steps already start at a known height.

### `_timeout_for`: how long a move may take

```python
distance = max(abs(t - p) for t, p in zip(target, self.driver.position))
return distance / self.config.speed * self.TIMEOUT_FACTOR + self.TIMEOUT_MARGIN_S
```

- **The longest axis distance divided by speed** gives the expected time. It mirrors how the simulator plans: the longest axis sets the duration.
- The expected time is multiplied by 1.5, plus 2 s of margin. The 1253 mm move to the destination takes about 12.5 s, so it would time out after about 20.8 s.
- A fixed timeout would either be too short for long moves or useless for short ones.

### `_on_timeout`

```python
def _on_timeout(self):
    self.last_error = f"Motion timed out in {self.state}"
    return BaseTriggers.TO_FAULT.value
```

The library calls this to get a trigger name, so we record **why** before returning `"to_fault"`. Otherwise the fault would arrive with no message.

### `_fault`

Records the message, then fires `to_fault`.

### `_fire`: turning refusals into messages

```python
try:
    allowed = self.trigger(name)
except MachineError:
    return self._not_ready(...)       # no transition from this state
return None if allowed else f"Cannot {name} right now"   # a guard said no
```

The library refuses in two different ways:

- **No transition** from the current state, e.g. start while homing: `MachineError` becomes "Cannot start sequence while the machine is in state 'Homing_moving'".
- **A guard blocked it:** the result is `False`, which becomes "Cannot … right now".

### The remaining helpers

- `_not_ready(action)`: one consistent message format.
- `_cube_xy()` and `_destination_xy()`: the configured table points converted to robot coordinates with `table_point_to_robot_frame`.
- `_above(xy)`: the point at travel height.

---

## 12. `_loop_running()`

```python
def _loop_running() -> bool:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return False
    return True
```

`asyncio.current_task()` raises an error if no event loop is running, which can happen if a fault is triggered from plain synchronous code, such as some tests. This lets `_enter_fault` work either way.

---

## 13. The simulated cube

The simulator has no cube, so the machine tracks one to make the dashboard meaningful:

- **Before pickup:** `_cube_rest` = (cube x, cube y, pick_z) on Table A.
- **`grip`** sets `_holding_cube = True`. From then on `cube_position` returns the **robot's** position, so the cube moves with the gripper.
- **`release`** sets `_cube_rest` to the robot's current position and `_holding_cube = False`, so the cube stays on Table B.
- **`update_config`** and the start of each sequence put it back at the configured start.

---

## What this file deliberately doesn't do

- **HTTP and streaming:** that's `api.py`. It only exposes `request_*`, `update_config` and `status()`.
- **Saving the config:** `config_store.py`. The machine just holds the current one in memory.
- **Raw `robot_sim` calls:** it always goes through `RobotDriver`, so the simulator's quirks are handled in one place.
