# `backend/app/robot_driver.py` walkthrough

## 1. Why the file exists (module docstring)

The provided `robot_sim.Robot` works, but it's awkward to use directly. The exercise says not to change it, so this file wraps it in a cleaner, safe-to-use class called `RobotDriver`. The docstring lists the five simulator problems the wrapper works around:

1. `move_to` doesn't block, and must be called repeatedly until the target is reached.
2. Errors come back as a string inside the return tuple, not as an exception.
3. Speed 0 passes the simulator's validation but then divides by zero.
4. On completion it stores the caller's list as its position (aliasing). Its constructor also has shared mutable default lists.
5. An interrupted motion leaves a stale `axis_speed` that skews the next one.

Each one comes up again below.

---

## 2. Imports and constants

```python
from __future__ import annotations
import asyncio
from typing import Optional, Sequence
from robot_sim import GripperState, Robot

POLL_INTERVAL_S = 0.02
MAX_SPEED = 100
```

- `from __future__ import annotations` makes type hints lazy, so newer hint syntax works on Python 3.10.
- `asyncio`: moves are `async`, so the program stays responsive while the robot moves. The API keeps answering and telemetry keeps streaming.
- `Sequence[float]`: functions accept a list *or* a tuple for positions.
- `POLL_INTERVAL_S = 0.02`: how often we call `move_to` during a move, 50 times per second. That's smooth enough for the dashboard and cheap on the CPU.
- `MAX_SPEED = 100`: the simulator's speed limit in mm/s.

---

## 3. `MotionError`

```python
class MotionError(Exception):
    """Raised when the simulator rejects or fails a motion."""
```

**Problem 2:** the simulator doesn't raise errors. It returns them as a string inside its result tuple, which is easy to forget to check. We convert those strings into a real exception, so a failed move can't go unnoticed. The state machine catches `MotionError` and goes to `fault`.

---

## 4. Constructor

```python
def __init__(self, robot: Optional[Robot] = None, home_position=(0.0, 0.0, 0.0)):
    self._robot = robot or Robot(
        initial_position=[0.0, 0.0, 0.0],
        home_position=[float(v) for v in home_position],
    )
    self._moving = False
```

- `robot`: you can pass in an existing `Robot` (useful in tests). Otherwise it creates one.
- **Problem 4a, shared default lists:** `Robot.__init__` uses `initial_position=[0,0,0]` as a default argument. In Python, a default list is created **once** and shared by every call. Two robots built with defaults would share the same position list. Passing fresh lists every time avoids that.
- `float(v)` keeps everything as floats, so a position never mixes `0` and `0.0`.
- `self._moving` is our own "in motion" flag; the simulator doesn't provide one.
- The leading underscore in `_robot` and `_moving` marks them as internal. Other code goes through the properties below.

---

## 5. Read-only properties

```python
@property
def position(self) -> list[float]:
    return list(self._robot.current_position)
```

It returns a **copy** of the position. If a caller changes the returned list, the robot isn't affected.

**How do we know it's a copy?** Calling `list()` on an existing list always builds a **new list object** containing the same items. A quick check against the real driver confirms it:

```
position is internal list: False | equal values: True
home is internal list:     False | equal values: True
after mutating returned lists -> [0.0, 0.0, 0.0] [1.0, 2.0, 3.0]
```

`is` compares object identity, so `False` means a different list with the same contents. Two details:

- **It's a shallow copy,** meaning only the outer list is new. That's enough here because the items are floats, and floats can't be changed in place.
- **Test coverage:** `test_caller_list_is_not_aliased` checks this for `position`. Nothing tests `home_position` yet.

```python
@property
def home_position(self) -> list[float]:
    return list(self._robot.home_position)

@home_position.setter
def home_position(self, value):
    self._robot.home_position = self._as_target(value)
```

Reading it returns a copy as well. Setting it checks the value has 3 axes and stores fresh floats. The state machine uses this when the configured home position changes.

```python
@property
def limits(self) -> list[float]:
    return list(self._robot.robot_limits)
```

The maximum absolute position per axis (±1000 mm). The state machine and config validation use it to refuse out-of-range targets before a move is attempted. It also returns a copy.

```python
@property
def gripper_closed(self) -> bool:
    return self._robot.gripper_state == GripperState.CLOSED
```

It turns the simulator's `GripperState` enum into a plain `True`/`False`, which is simpler for the API and the frontend.

```python
@property
def is_moving(self) -> bool:
    return self._moving
```

Telemetry's "moving / idle" field reads this.

---

## 6. Gripper

```python
def open_gripper(self) -> None:
    self._robot.open_gripper()

def close_gripper(self) -> None:
    self._robot.closed_gripper()
```

These are thin pass-throughs with consistent names. The simulator's `closed_gripper` doesn't match `open_gripper`, and its return types are inconsistent: one returns the enum and the other claims to return a bool. Ours return nothing, and you read the state through `gripper_closed`.

---

## 7. `move()`: the core

```python
async def move(self, target: Sequence[float], speed: int) -> list[float]:
```

`speed` is an `int` to match the simulator's `move_to(..., speed: int)`, so speeds are whole mm/s from 1 to 100. Casting a float with `int(speed)` instead would silently turn 0.5 into 0, the divide-by-zero case.

### a) Validate the speed

```python
if not (0 < speed <= MAX_SPEED):
    raise MotionError(...)
```

**Problem 3:** the simulator accepts `0 <= speed`, but speed 0 then divides by zero (`motion_time = distance / speed`) and crashes. We require speed > 0. Its upper limit of 100 is kept.

### b) Normalise the target

```python
goal = self._as_target(target)
```

This checks for exactly 3 axes and makes a fresh list of floats, which we own. Section 9 explains why that matters.

### c) Clear any previous plan

```python
self._robot.axis_speed = [0, 0, 0]
```

**Problem 5:** the simulator only plans a new motion when `axis_speed` is all zeros. If a previous move was interrupted (by a fault or a cancel), `axis_speed` still holds the old direction, so the next `move_to` would carry on in the **old** direction toward the new target. Zeroing it forces a fresh plan.

### d) The polling loop

```python
self._moving = True
try:
    while True:
        position, _, error = self._robot.move_to(list(goal), speed)
        if error:
            raise MotionError(error)
        if position == goal:
            return list(position)
        await asyncio.sleep(POLL_INTERVAL_S)
```

- **Problem 1:** `move_to` doesn't block. Each call moves the robot by *speed × time since the last call*, then returns. The README says it must be called repeatedly, so we loop.
- `list(goal)`: **problem 4b, aliasing.** When the simulator finishes, it does `self.current_position = target_position`, which stores **the list we passed in**. If that were `goal`, or the caller's own list, the robot's position and that list would become the same object, and changing one would change the other. Passing a throwaway copy each call prevents it.
- `_` ignores the axis speeds that `move_to` returns; we don't need them.
- `if error`: turns the string into an exception (problem 2).
- `if position == goal`: the move is done. The simulator snaps exactly onto the target when it finishes, so an exact comparison is safe, with no rounding issues.
- `await asyncio.sleep(...)`: waits 20 ms **without blocking** anything else. The API and telemetry keep running during a move. A plain `time.sleep` would freeze the whole server.

**Why `while True` instead of `while position != goal`?** It's mostly style; both work. We only learn the new position *after* calling `move_to`, so with a loop condition each pass goes call, then sleep, then check:

```python
position = self.position
while position != goal:
    position, _, error = self._robot.move_to(list(goal), speed)
    if error:
        raise MotionError(error)
    await asyncio.sleep(POLL_INTERVAL_S)
return position
```

That always sleeps once more **after** arriving, adding 20 ms per move (about 0.2 s over a whole cycle). Avoiding it would need a second `if position == goal` check before the sleep, which duplicates the loop condition. `while True` puts the single exit check right after the call, so it returns as soon as the robot arrives. The other version states the loop's purpose in its first line and would also be fine.

### e) Clean up, always

```python
finally:
    self._robot.axis_speed = [0, 0, 0]
    self._moving = False
```

`finally` runs however the loop ends: success, `MotionError`, or **cancellation**. When the state machine faults it cancels the task, `asyncio.sleep` raises `CancelledError`, and this block still runs. The robot then stops cleanly where it is: no stale plan, and `is_moving` is `False`. A test cancels a move halfway and checks that the next move goes exactly where it should.

---

## 8. `home()`

```python
async def home(self, speed: int = 50) -> list[float]:
    return await self.move(self._robot.home_position, speed)
```

It moves to the configured home position, which defaults to `[0, 0, 0]`. We don't call the simulator's `move_home()`, because it calls `move_to` only **once**. It would return after a single tiny step, and its `-> bool` annotation is wrong besides. Reusing our own `move()` gives homing the same polling, error handling and cleanup. The default speed of 50 mirrors the simulator's `move_home`.

---

## 9. `_as_target()` helper

```python
@staticmethod
def _as_target(value) -> list[float]:
    if len(value) != 3:
        raise MotionError(...)
    return [float(v) for v in value]
```

- It rejects anything that isn't X, Y, Z. The simulator would otherwise crash with an obscure `IndexError` or silently ignore extra values.
- It returns a **new** list of floats. That makes `goal` our own copy (section 7b), and `position == goal` compares like with like.
- `@staticmethod`: it doesn't use `self`, it's just a utility kept in the class.

---

## What this file deliberately doesn't do

- **Table coordinates.** It only knows robot-frame mm; converting from a table is `geometry.py`'s job.
- **The pick-and-place sequence or faults.** It raises `MotionError`, and the state machine decides what that means.
- **Simultaneous moves.** If two `move()` calls ran at once they'd fight over the robot. The state machine prevents that, since only one state, and so one move, is active at a time.
