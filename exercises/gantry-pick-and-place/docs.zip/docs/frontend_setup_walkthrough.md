# Step 4 walkthrough: frontend setup and API client

Step 4 builds the frontend's plumbing: a React + TypeScript project, a **typed client generated from the backend's proto**, a hook that keeps the telemetry stream alive, and a temporary page proving the connection works. Step 5 replaces that page with the real dashboard.

```
backend/proto/app.proto ──buf generate──▶ frontend/src/gen/app_pb.ts   (typed messages + service)
                                                │
src/api/client.ts      createClient(GantryAppService, connect transport) ──HTTP──▶ backend :8000/rpc
src/api/useTelemetry.ts  for await (msg of gantry.telemetry()) → React state, reconnects
src/App.tsx            temporary page: connection badge, Home button, raw telemetry
```

---

## 1. Project setup

```
npx create-vite@6.5.0 frontend --template react-ts
```

- **Vite** is the dev server and bundler; the `react-ts` template gives React 19 and TypeScript, already configured.
- The version is pinned (6.5.0) so the result is reproducible and the command doesn't ask interactive questions.
- **Dependencies added:**
  - Runtime: `@bufbuild/protobuf` (the protobuf runtime), `@connectrpc/connect` and `@connectrpc/connect-web` (the Connect client and its browser transport).
  - Development only: `@bufbuild/buf` (the code generator CLI, as an npm package) and `@bufbuild/protoc-gen-es` (the plugin that writes TypeScript).
  - Everything lives in `node_modules`, so **nothing is installed globally**: `npm install` is enough for anyone cloning the repo.
- **Versions: Connect v2 / protobuf-es v2.** The `vention-communication` README shows the older v1 style (`app_connect.ts` from a second plugin). In v2, a single plugin generates both the messages and the service description, so the setup is simpler. The wire protocol is the same.
- **Template leftovers removed:** `App.css` and `src/assets/react.svg` (no longer used). `index.html`'s title is now "Gantry Pick & Place". `frontend/README.md` is still Vite's template README (to be decided in the final README pass).
- **`package.json` byte-order mark:** PowerShell had written an invisible BOM at the start of `package.json`, which made Vite's JSON parser fail. It was stripped. Worth knowing if a JSON file ever breaks for no visible reason on Windows.

---

## 2. Code generation (`buf.gen.yaml` + npm scripts)

```yaml
version: v2
inputs:
  - directory: ../backend/proto
plugins:
  - local: protoc-gen-es
    out: src/gen
    opt: target=ts
clean: true
```

- **Input:** the `app.proto` the backend writes at startup (`emit_proto=True`). It's the contract between the two sides.
- **Plugin:** `protoc-gen-es` from `node_modules/.bin`. npm puts that folder on the PATH while running scripts, which is how `local:` finds it.
- `target=ts` writes TypeScript (instead of JavaScript plus `.d.ts` files).
- `clean: true` empties `src/gen` first, so a renamed message never leaves stale files behind.
- `google/protobuf/empty.proto` (imported by the proto for actions without input) is a well-known type that Buf provides itself.

**Scripts in `package.json`:**

```json
"gen": "buf generate",
"predev": "npm run gen",
"prebuild": "npm run gen",
```

npm runs `pre<name>` automatically before `<name>`, so `npm run dev` and `npm run build` always regenerate the client first. The generated code can never be out of date with the proto.

**`src/gen/` is git-ignored** (added to `frontend/.gitignore`) because it's rebuilt on every `dev` and `build`. ESLint also ignores it (`eslint.config.js`), since generated code isn't ours to lint. This relies on `backend/proto/app.proto` being committed, which is why committing it was suggested in Step 3.

### What gets generated (`src/gen/app_pb.ts`)

- **A type per message**, with camelCase field names: `Telemetry` has `state`, `position`, `gripperClosed`, `moving`, `cubePosition`, `destinationPosition`, `error`.
- **Nested messages are optional** (`position?: Point3 | undefined`). Proto3 can't tell "zero" from "absent" for messages. Step 5's UI has to handle a missing position.
- **`GantryAppService`**, describing every RPC. Method names keep the proto spelling: `get_config`, `home_robot`, `telemetry`, …
- **Schemas** (`TelemetrySchema`, …) used for things like `toJson`.

**JSON names match the backend's behaviour (Step 3):** the client **sends** camelCase (`pickZ`), which the backend accepts. It **reads** the backend's snake_case responses (`gripper_closed`), because protobuf JSON parsers accept the proto field name too. This was confirmed live: the page receives every field correctly.

---

## 3. `src/api/client.ts`

```ts
export const API_BASE_URL: string =
  import.meta.env.VITE_API_URL ?? "http://localhost:8000/rpc";

const transport = createConnectTransport({
  baseUrl: API_BASE_URL,
  useBinaryFormat: false,
});

export const gantry = createClient(GantryAppService, transport);
```

- **`API_BASE_URL`:** the backend's RPC root. It defaults to the local backend, and can be overridden with a `VITE_API_URL` variable (e.g. in `.env.local`), useful later for Docker. Vite exposes only variables starting with `VITE_` to browser code. `vite-env.d.ts` declares it so TypeScript knows its type.
- **`useBinaryFormat: false`:** the backend library only speaks the Connect protocol's JSON encoding, not binary protobuf.
- **`gantry`:** one shared, typed client. `gantry.home_robot({})` returns `Promise<CommandResult>`, and `gantry.telemetry({})` returns an async stream of `Telemetry`. A typo in a method or field name is a compile error.

```ts
export async function runCommand(call: () => Promise<CommandResult>): Promise<CommandOutcome> {
  try {
    const result = await call();
    return { ok: result.ok, error: result.error };
  } catch (err) {
    return { ok: false, error: describeError(err) };
  }
}
```

A command can fail in two different ways, and `runCommand` turns both into the same `{ok, error}` shape for the UI:

- **The backend refused it.** The call succeeds and returns `{ok: false, error: "Cannot start sequence while …"}` (the backend's design from Step 3).
- **The call itself failed** (backend down, network error, bad response). The Connect client **throws** a `ConnectError`. `describeError` turns it into "Backend unreachable or failed: …".

So the UI never needs a `try/catch` per button.

---

## 4. `src/api/useTelemetry.ts`

A React hook that returns `{ telemetry, connection }`:
- `telemetry`: the latest `Telemetry` message, or `null` before the first one.
- `connection`: `"connecting"`, `"connected"` or `"disconnected"`.

### The loop

```ts
while (!unmounted.signal.aborted) {
  const attempt = new AbortController();
  ...
  try {
    for await (const message of gantry.telemetry({}, { signal: attempt.signal })) {
      // reset watchdog
      setTelemetry(message);
      setConnection("connected");
    }
  } catch {
    // error or abort
  } finally {
    // clear watchdog, remove listener
  }
  if (unmounted.signal.aborted) return;
  setConnection("disconnected");
  await sleep(RETRY_AFTER_MS);
}
```

- **`for await`** reads the server stream message by message, as the backend publishes them (about 17–20 per second).
- **The stream normally never ends.** The loop only moves on when the stream throws (backend stopped, network dropped) or is aborted. Either way the hook marks itself `disconnected`, waits 1 s, and subscribes again. So **restarting the backend doesn't need a page reload**.
- **Two abort controllers:**
  - `unmounted` lives for the whole hook. It's aborted in the effect's cleanup (`return () => unmounted.abort()`), when the component unmounts, and stops everything for good.
  - `attempt` is new for each subscription, so one stream can be dropped without ending the loop. An `abort` listener links them: unmounting also aborts the current attempt.
- **Watchdog (`STALE_AFTER_MS = 2000`):** a connection can also die *silently* (e.g. a network change) without an error. The hook expects a message every ~50 ms. If none arrives for 2 s, it aborts the attempt, which leads to the reconnect path. Each message resets the timer.
- **Last value kept while disconnected:** `telemetry` isn't cleared on disconnect. Step 5 can show the last known state greyed out with a "disconnected" warning, instead of a blank screen.
- **React StrictMode:** in development React mounts, unmounts and remounts components once to catch bugs. The cleanup aborts the first subscription, so there's never a duplicate stream.
- `void run()` starts the async loop from the synchronous effect; `void` marks the ignored promise as intentional.

---

## 5. `src/App.tsx` (temporary)

A connection check, replaced in Step 5:
- the backend URL and a **badge** for the connection state (green, grey or red);
- a **Home robot** button, disabled while a request is in flight or while disconnected, with the outcome shown underneath ("Home accepted" or "Refused: …");
- the **raw telemetry** as JSON. `toJson(..., { alwaysEmitImplicit: true })` prints every field: by default protobuf JSON leaves out zero, `false` and empty values, which made the position at (0, 0, 0) show as `{}`.

`index.css` holds a few base styles for this page (badge colours, light/dark support via `color-scheme`), to be reworked in Step 5.

---

## 6. Verification

- `npm run build` (type check + production build) and `npm run lint` both pass.
- With the backend on :8000 and `npm run dev` on :5173, in the browser pane:
  - The badge showed **connected**, and the raw telemetry updated live. The cube position showed (−800, 800), the config saved in Step 3's restart test, so persistence is visible from the frontend too.
  - The robot was first jogged to (300, 200, −100) over HTTP. Then **Home robot** was clicked in the page: "Home accepted". Mid-move the stream showed `Homing_moving` with `moving: true` and the robot **lifting first** (z rising while x and y stayed at 300, 200). It then reached `ready` at (0, 0, 0).
  - **Reconnect:** stopping the backend turned the badge **disconnected** within a few seconds. Starting it again turned it back to **connected**, with no page reload.
- The only console error was the expected `ERR_CONNECTION_RESET` while the backend was stopped.

**A Windows gotcha found on the way:** `npm run dev -- --port 5173` in PowerShell passed `5173` to Vite as its *root folder* (PowerShell consumed `--port`), so every page was a 404. Port 5173 is Vite's default anyway, so plain `npm run dev` is enough.

---

## How to run it

Two terminals:

```
cd backend
venv\Scripts\activate
uvicorn app.main:app --port 8000
```

```
cd frontend
npm install        # first time only
npm run dev        # regenerates the client, then serves http://localhost:5173
```
